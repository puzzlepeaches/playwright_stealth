# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['playwright_stealth']

package_data = \
{'': ['*'], 'playwright_stealth': ['js/*']}

install_requires = \
['playwright']

setup_kwargs = {
    'name': 'playwright-stealth',
    'version': '0.1.0',
    'description': '',
    'long_description': "# playwright_stealth\n\nTransplanted from [puppeteer-extra-plugin-stealth](https://github.com/berstend/puppeteer-extra/tree/master/packages/puppeteer-extra-plugin-stealth), **Not perfect**.\n\n## Install\n\n```\n$ pip install playwright-stealth\n```\n\n## Usage\n### sync\n```python\n\nfrom playwright.sync_api import sync_playwright\nfrom playwright_stealth import stealth_sync\n\nwith sync_playwright() as p:\n    for browser_type in [p.chromium, p.firefox, p.webkit]:\n        browser = browser_type.launch()\n        page = browser.new_page()\n        stealth_sync(page)\n        page.goto('http://whatsmyuseragent.org/')\n        page.screenshot(path=f'example-{browser_type.name}.png')\n        browser.close()\n\n```\n### async\n```python\n# -*- coding: utf-8 -*-\nimport asyncio\nfrom playwright.async_api import async_playwright\nfrom playwright_stealth import stealth_async\n\nasync def main():\n    async with async_playwright() as p:\n        for browser_type in [p.chromium, p.firefox, p.webkit]:\n            browser = await browser_type.launch()\n            page = await browser.new_page()\n            await stealth_async(page)\n            await page.goto('http://whatsmyuseragent.org/')\n            await page.screenshot(path=f'example-{browser_type.name}.png')\n            await browser.close()\n\nasyncio.get_event_loop().run_until_complete(main())\n```\n\n## Test results\n\n### playwright with stealth\n\n![playwright without stealth](https://github.com/ASAS1314/playwright_stealth/blob/main/images/example.png)\n\n### playwright without stealth\n\n![playwright with stealth](https://github.com/ASAS1314/playwright_stealth/blob/main/images/example1.png)\n",
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
